﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl3
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        SearchCustomer = New TextBox()
        Label3 = New Label()
        CustomerDataView = New DataGridView()
        CType(CustomerDataView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top
        Label2.AutoSize = True
        Label2.BackColor = Color.LightGray
        Label2.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(448, 23)
        Label2.Name = "Label2"
        Label2.Size = New Size(385, 40)
        Label2.TabIndex = 4
        Label2.Text = "CUSTOMER INFORMATION"
        ' 
        ' SearchCustomer
        ' 
        SearchCustomer.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        SearchCustomer.Font = New Font("Segoe UI", 15.75F)
        SearchCustomer.Location = New Point(987, 115)
        SearchCustomer.Multiline = True
        SearchCustomer.Name = "SearchCustomer"
        SearchCustomer.Size = New Size(201, 41)
        SearchCustomer.TabIndex = 9
        SearchCustomer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(1018, 82)
        Label3.Name = "Label3"
        Label3.Size = New Size(142, 30)
        Label3.TabIndex = 14
        Label3.Text = "SEARCH BAR"
        ' 
        ' CustomerDataView
        ' 
        CustomerDataView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        CustomerDataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        CustomerDataView.Location = New Point(92, 181)
        CustomerDataView.Name = "CustomerDataView"
        CustomerDataView.Size = New Size(1096, 458)
        CustomerDataView.TabIndex = 15
        ' 
        ' UserControl3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        Controls.Add(CustomerDataView)
        Controls.Add(Label3)
        Controls.Add(SearchCustomer)
        Controls.Add(Label2)
        Name = "UserControl3"
        Size = New Size(1280, 720)
        CType(CustomerDataView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents SearchCustomer As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CustomerDataView As DataGridView

End Class
