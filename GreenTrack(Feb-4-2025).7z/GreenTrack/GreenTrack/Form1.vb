﻿Public Class Form1
    Private Sub LogInButton_Click(sender As Object, e As EventArgs) Handles LogInButton.Click
        Form2.Show()
        Me.Hide()
    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub
End Class
