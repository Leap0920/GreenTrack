﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl1
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        AddPlantButton = New Button()
        UpdateButton = New Button()
        Stocks = New TextBox()
        InventoryDataView = New DataGridView()
        Label1 = New Label()
        PlantName = New TextBox()
        Label3 = New Label()
        CType(InventoryDataView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(334, 32)
        Label2.Name = "Label2"
        Label2.Size = New Size(399, 40)
        Label2.TabIndex = 2
        Label2.Text = "INVENTORY MANAGEMENT"
        ' 
        ' AddPlantButton
        ' 
        AddPlantButton.Anchor = AnchorStyles.Bottom
        AddPlantButton.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        AddPlantButton.Location = New Point(430, 616)
        AddPlantButton.Name = "AddPlantButton"
        AddPlantButton.Size = New Size(202, 41)
        AddPlantButton.TabIndex = 3
        AddPlantButton.Text = "ADD PLANT"
        AddPlantButton.UseVisualStyleBackColor = True
        ' 
        ' UpdateButton
        ' 
        UpdateButton.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        UpdateButton.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        UpdateButton.Location = New Point(941, 569)
        UpdateButton.Name = "UpdateButton"
        UpdateButton.Size = New Size(202, 41)
        UpdateButton.TabIndex = 4
        UpdateButton.Text = "UPDATE"
        UpdateButton.UseVisualStyleBackColor = True
        ' 
        ' Stocks
        ' 
        Stocks.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Stocks.Font = New Font("Segoe UI", 15.75F)
        Stocks.Location = New Point(940, 239)
        Stocks.Multiline = True
        Stocks.Name = "Stocks"
        Stocks.Size = New Size(201, 41)
        Stocks.TabIndex = 5
        Stocks.TextAlign = HorizontalAlignment.Center
        ' 
        ' InventoryDataView
        ' 
        InventoryDataView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        InventoryDataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        InventoryDataView.Location = New Point(138, 115)
        InventoryDataView.Name = "InventoryDataView"
        InventoryDataView.Size = New Size(784, 495)
        InventoryDataView.TabIndex = 6
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(1001, 206)
        Label1.Name = "Label1"
        Label1.Size = New Size(76, 30)
        Label1.TabIndex = 7
        Label1.Text = "Stocks"
        ' 
        ' PlantName
        ' 
        PlantName.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        PlantName.Font = New Font("Segoe UI", 15.75F)
        PlantName.Location = New Point(941, 154)
        PlantName.Multiline = True
        PlantName.Name = "PlantName"
        PlantName.Size = New Size(201, 41)
        PlantName.TabIndex = 8
        PlantName.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(978, 121)
        Label3.Name = "Label3"
        Label3.Size = New Size(128, 30)
        Label3.TabIndex = 9
        Label3.Text = "Plant Name"
        ' 
        ' UserControl1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        Controls.Add(Label3)
        Controls.Add(PlantName)
        Controls.Add(Label1)
        Controls.Add(InventoryDataView)
        Controls.Add(Stocks)
        Controls.Add(UpdateButton)
        Controls.Add(AddPlantButton)
        Controls.Add(Label2)
        Name = "UserControl1"
        Size = New Size(1280, 720)
        CType(InventoryDataView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents AddPlantButton As Button
    Friend WithEvents UpdateButton As Button
    Friend WithEvents Stocks As TextBox
    Friend WithEvents InventoryDataView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents PlantName As TextBox
    Friend WithEvents Label3 As Label

End Class
