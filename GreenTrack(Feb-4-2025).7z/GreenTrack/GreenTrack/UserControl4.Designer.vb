﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl4
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        Label14 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label15 = New Label()
        FirstName = New TextBox()
        LastName = New TextBox()
        PhoneNumber = New TextBox()
        ReserveDate = New TextBox()
        ReserveTime = New TextBox()
        PickupTime = New TextBox()
        PickupDate = New TextBox()
        EmailAddress = New TextBox()
        PlantName = New TextBox()
        Quantity = New TextBox()
        SpecRequest = New TextBox()
        ReserveButton = New Button()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top
        Label2.AutoSize = True
        Label2.BackColor = Color.LightGray
        Label2.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(525, 18)
        Label2.Name = "Label2"
        Label2.Size = New Size(231, 40)
        Label2.TabIndex = 5
        Label2.Text = "RESERVATIONS:"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(183, 103)
        Label3.Name = "Label3"
        Label3.Size = New Size(71, 30)
        Label3.TabIndex = 14
        Label3.Text = "Name"
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label1.Location = New Point(183, 180)
        Label1.Name = "Label1"
        Label1.Size = New Size(75, 17)
        Label1.TabIndex = 15
        Label1.Text = "First Name"
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Top
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label4.Location = New Point(406, 180)
        Label4.Name = "Label4"
        Label4.Size = New Size(73, 17)
        Label4.TabIndex = 16
        Label4.Text = "Last Name"
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(183, 226)
        Label5.Name = "Label5"
        Label5.Size = New Size(163, 30)
        Label5.TabIndex = 17
        Label5.Text = "Phone Number"
        ' 
        ' Label6
        ' 
        Label6.Anchor = AnchorStyles.Top
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(183, 329)
        Label6.Name = "Label6"
        Label6.Size = New Size(303, 30)
        Label6.TabIndex = 18
        Label6.Text = "Date of Reservation and Time"
        ' 
        ' Label7
        ' 
        Label7.Anchor = AnchorStyles.Top
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label7.Location = New Point(338, 406)
        Label7.Name = "Label7"
        Label7.Size = New Size(39, 17)
        Label7.TabIndex = 20
        Label7.Text = "Time"
        ' 
        ' Label8
        ' 
        Label8.Anchor = AnchorStyles.Top
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label8.Location = New Point(183, 406)
        Label8.Name = "Label8"
        Label8.Size = New Size(37, 17)
        Label8.TabIndex = 19
        Label8.Text = "Date"
        ' 
        ' Label11
        ' 
        Label11.Anchor = AnchorStyles.Top
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(183, 459)
        Label11.Name = "Label11"
        Label11.Size = New Size(295, 30)
        Label11.TabIndex = 23
        Label11.Text = "Preferred Pick-up Date & Time"
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Top
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(691, 103)
        Label12.Name = "Label12"
        Label12.Size = New Size(150, 30)
        Label12.TabIndex = 24
        Label12.Text = "Email Address"
        ' 
        ' Label13
        ' 
        Label13.Anchor = AnchorStyles.Top
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(691, 186)
        Label13.Name = "Label13"
        Label13.Size = New Size(128, 30)
        Label13.TabIndex = 25
        Label13.Text = "Plant Name"
        ' 
        ' Label14
        ' 
        Label14.Anchor = AnchorStyles.Top
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(897, 186)
        Label14.Name = "Label14"
        Label14.Size = New Size(99, 30)
        Label14.TabIndex = 26
        Label14.Text = "Quantity"
        ' 
        ' Label9
        ' 
        Label9.Anchor = AnchorStyles.Top
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label9.Location = New Point(338, 536)
        Label9.Name = "Label9"
        Label9.Size = New Size(39, 17)
        Label9.TabIndex = 28
        Label9.Text = "Time"
        ' 
        ' Label10
        ' 
        Label10.Anchor = AnchorStyles.Top
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label10.Location = New Point(183, 536)
        Label10.Name = "Label10"
        Label10.Size = New Size(37, 17)
        Label10.TabIndex = 27
        Label10.Text = "Date"
        ' 
        ' Label15
        ' 
        Label15.Anchor = AnchorStyles.Top
        Label15.AutoSize = True
        Label15.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(691, 313)
        Label15.Name = "Label15"
        Label15.Size = New Size(181, 30)
        Label15.TabIndex = 29
        Label15.Text = "Special Requests:"
        ' 
        ' FirstName
        ' 
        FirstName.Anchor = AnchorStyles.Top
        FirstName.Font = New Font("Segoe UI", 15.75F)
        FirstName.Location = New Point(183, 136)
        FirstName.Multiline = True
        FirstName.Name = "FirstName"
        FirstName.Size = New Size(194, 41)
        FirstName.TabIndex = 30
        ' 
        ' LastName
        ' 
        LastName.Anchor = AnchorStyles.Top
        LastName.Font = New Font("Segoe UI", 15.75F)
        LastName.Location = New Point(406, 136)
        LastName.Multiline = True
        LastName.Name = "LastName"
        LastName.Size = New Size(194, 41)
        LastName.TabIndex = 31
        ' 
        ' PhoneNumber
        ' 
        PhoneNumber.Anchor = AnchorStyles.Top
        PhoneNumber.Font = New Font("Segoe UI", 15.75F)
        PhoneNumber.Location = New Point(183, 259)
        PhoneNumber.Multiline = True
        PhoneNumber.Name = "PhoneNumber"
        PhoneNumber.Size = New Size(304, 41)
        PhoneNumber.TabIndex = 32
        ' 
        ' ReserveDate
        ' 
        ReserveDate.Anchor = AnchorStyles.Top
        ReserveDate.Font = New Font("Segoe UI", 15.75F)
        ReserveDate.Location = New Point(183, 362)
        ReserveDate.Multiline = True
        ReserveDate.Name = "ReserveDate"
        ReserveDate.Size = New Size(149, 41)
        ReserveDate.TabIndex = 33
        ' 
        ' ReserveTime
        ' 
        ReserveTime.Anchor = AnchorStyles.Top
        ReserveTime.Font = New Font("Segoe UI", 15.75F)
        ReserveTime.Location = New Point(338, 362)
        ReserveTime.Multiline = True
        ReserveTime.Name = "ReserveTime"
        ReserveTime.Size = New Size(149, 41)
        ReserveTime.TabIndex = 34
        ' 
        ' PickupTime
        ' 
        PickupTime.Anchor = AnchorStyles.Top
        PickupTime.Font = New Font("Segoe UI", 15.75F)
        PickupTime.Location = New Point(338, 492)
        PickupTime.Multiline = True
        PickupTime.Name = "PickupTime"
        PickupTime.Size = New Size(149, 41)
        PickupTime.TabIndex = 36
        ' 
        ' PickupDate
        ' 
        PickupDate.Anchor = AnchorStyles.Top
        PickupDate.Font = New Font("Segoe UI", 15.75F)
        PickupDate.Location = New Point(183, 492)
        PickupDate.Multiline = True
        PickupDate.Name = "PickupDate"
        PickupDate.Size = New Size(149, 41)
        PickupDate.TabIndex = 35
        ' 
        ' EmailAddress
        ' 
        EmailAddress.Anchor = AnchorStyles.Top
        EmailAddress.Font = New Font("Segoe UI", 15.75F)
        EmailAddress.Location = New Point(691, 136)
        EmailAddress.Multiline = True
        EmailAddress.Name = "EmailAddress"
        EmailAddress.Size = New Size(406, 41)
        EmailAddress.TabIndex = 37
        ' 
        ' PlantName
        ' 
        PlantName.Anchor = AnchorStyles.Top
        PlantName.Font = New Font("Segoe UI", 15.75F)
        PlantName.Location = New Point(691, 219)
        PlantName.Multiline = True
        PlantName.Name = "PlantName"
        PlantName.Size = New Size(200, 41)
        PlantName.TabIndex = 38
        ' 
        ' Quantity
        ' 
        Quantity.Anchor = AnchorStyles.Top
        Quantity.Font = New Font("Segoe UI", 15.75F)
        Quantity.Location = New Point(897, 219)
        Quantity.Multiline = True
        Quantity.Name = "Quantity"
        Quantity.Size = New Size(200, 41)
        Quantity.TabIndex = 39
        ' 
        ' SpecRequest
        ' 
        SpecRequest.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        SpecRequest.Font = New Font("Segoe UI", 15.75F)
        SpecRequest.Location = New Point(691, 346)
        SpecRequest.Multiline = True
        SpecRequest.Name = "SpecRequest"
        SpecRequest.Size = New Size(406, 187)
        SpecRequest.TabIndex = 40
        ' 
        ' ReserveButton
        ' 
        ReserveButton.Anchor = AnchorStyles.Bottom
        ReserveButton.Location = New Point(897, 580)
        ReserveButton.Name = "ReserveButton"
        ReserveButton.Size = New Size(200, 57)
        ReserveButton.TabIndex = 41
        ReserveButton.Text = "RESERVE!"
        ReserveButton.UseVisualStyleBackColor = True
        ' 
        ' UserControl4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        Controls.Add(ReserveButton)
        Controls.Add(SpecRequest)
        Controls.Add(Quantity)
        Controls.Add(PlantName)
        Controls.Add(EmailAddress)
        Controls.Add(PickupTime)
        Controls.Add(PickupDate)
        Controls.Add(ReserveTime)
        Controls.Add(ReserveDate)
        Controls.Add(PhoneNumber)
        Controls.Add(LastName)
        Controls.Add(FirstName)
        Controls.Add(Label15)
        Controls.Add(Label9)
        Controls.Add(Label10)
        Controls.Add(Label14)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label7)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Name = "UserControl4"
        Size = New Size(1280, 720)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents FirstName As TextBox
    Friend WithEvents LastName As TextBox
    Friend WithEvents PhoneNumber As TextBox
    Friend WithEvents ReserveDate As TextBox
    Friend WithEvents ReserveTime As TextBox
    Friend WithEvents PickupTime As TextBox
    Friend WithEvents PickupDate As TextBox
    Friend WithEvents EmailAddress As TextBox
    Friend WithEvents PlantName As TextBox
    Friend WithEvents Quantity As TextBox
    Friend WithEvents SpecRequest As TextBox
    Friend WithEvents ReserveButton As Button

End Class
