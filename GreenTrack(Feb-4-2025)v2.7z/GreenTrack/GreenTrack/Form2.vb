﻿Public Class Form2
    Private sidebarExpanded As Boolean = False
    Private Sub ShowButton_Click(sender As Object, e As EventArgs) Handles ShowButton.Click
        If PanelSideBar.Width = 51 Then
            PanelSideBar.Width = 300
            PanelMain.Location = New Point(318, PanelMain.Location.Y)
            PanelMain.Width = Me.Width - 318
            ShowButton.Text = "➖"
        Else
            PanelSideBar.Width = 51
            PanelMain.Location = New Point(70, PanelMain.Location.Y)
            PanelMain.Width = Me.Width - 70
            ShowButton.Text = "➤"
        End If
    End Sub
    Private Sub Form2_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        PanelMain.Width = Me.Width - PanelSideBar.Width - 20
        PanelMain.Height = Me.Height - 50
    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Form2_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' Check if the user is closing the form
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo)

        If result = DialogResult.Yes Then
            Form1.Show()  ' Show Form1
        Else
            e.Cancel = True  ' Cancel the close action if the user clicked No
        End If
    End Sub

    Private Sub InventoryButton_Click(sender As Object, e As EventArgs) Handles InventoryButton.Click
        PanelMain.Controls.Clear() ' Clear previous content
        Dim inventoryControl As New UserControl1()
        inventoryControl.Dock = DockStyle.Fill
        PanelMain.Controls.Add(inventoryControl)
    End Sub

    Private Sub SalesButton_Click(sender As Object, e As EventArgs) Handles SalesButton.Click
        PanelMain.Controls.Clear() ' Clear previous content
        Dim SalesControl As New UserControl2()
        SalesControl.Dock = DockStyle.Fill
        PanelMain.Controls.Add(SalesControl)
    End Sub

    Private Sub CustomerButton_Click(sender As Object, e As EventArgs) Handles CustomerButton.Click
        PanelMain.Controls.Clear() ' Clear previous content
        Dim CustomerControl As New UserControl3()
        CustomerControl.Dock = DockStyle.Fill
        PanelMain.Controls.Add(CustomerControl)
    End Sub

    Private Sub ReservationButton_Click(sender As Object, e As EventArgs) Handles ReservationButton.Click
        PanelMain.Controls.Clear() ' Clear previous content
        Dim ReservationControl As New UserControl4()
        ReservationControl.Dock = DockStyle.Fill
        PanelMain.Controls.Add(ReservationControl)
    End Sub

    Private Sub ReportsButton_Click(sender As Object, e As EventArgs) Handles ReportsButton.Click
        PanelMain.Controls.Clear() ' Clear previous content
        Dim ReportOverviewControl As New UserControl5()
        ReportOverviewControl.Dock = DockStyle.Fill
        PanelMain.Controls.Add(ReportOverviewControl)
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class