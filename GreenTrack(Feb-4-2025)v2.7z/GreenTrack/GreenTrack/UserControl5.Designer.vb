﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl5
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        InvenStatusDataView = New DataGridView()
        FinanSummDataView = New DataGridView()
        DownloadButton = New Button()
        CType(InvenStatusDataView, ComponentModel.ISupportInitialize).BeginInit()
        CType(FinanSummDataView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(490, 19)
        Label2.Name = "Label2"
        Label2.Size = New Size(298, 40)
        Label2.TabIndex = 6
        Label2.Text = "REPORTS OVERVIEW"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(262, 100)
        Label3.Name = "Label3"
        Label3.Size = New Size(215, 30)
        Label3.TabIndex = 15
        Label3.Text = "INVENTORY STATUS"
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(778, 100)
        Label1.Name = "Label1"
        Label1.Size = New Size(241, 30)
        Label1.TabIndex = 16
        Label1.Text = "FINANCIAL SUMMARY"
        ' 
        ' InvenStatusDataView
        ' 
        InvenStatusDataView.Anchor = AnchorStyles.Top
        InvenStatusDataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        InvenStatusDataView.Location = New Point(211, 133)
        InvenStatusDataView.Name = "InvenStatusDataView"
        InvenStatusDataView.Size = New Size(338, 429)
        InvenStatusDataView.TabIndex = 17
        ' 
        ' FinanSummDataView
        ' 
        FinanSummDataView.Anchor = AnchorStyles.Top
        FinanSummDataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        FinanSummDataView.Location = New Point(731, 133)
        FinanSummDataView.Name = "FinanSummDataView"
        FinanSummDataView.Size = New Size(338, 429)
        FinanSummDataView.TabIndex = 18
        ' 
        ' DownloadButton
        ' 
        DownloadButton.Anchor = AnchorStyles.Top
        DownloadButton.Location = New Point(515, 609)
        DownloadButton.Name = "DownloadButton"
        DownloadButton.Size = New Size(250, 44)
        DownloadButton.TabIndex = 19
        DownloadButton.Text = "DOWNLOAD REPORT"
        DownloadButton.UseVisualStyleBackColor = True
        ' 
        ' UserControl5
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        Controls.Add(DownloadButton)
        Controls.Add(FinanSummDataView)
        Controls.Add(InvenStatusDataView)
        Controls.Add(Label1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Name = "UserControl5"
        Size = New Size(1280, 720)
        CType(InvenStatusDataView, ComponentModel.ISupportInitialize).EndInit()
        CType(FinanSummDataView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents InvenStatusDataView As DataGridView
    Friend WithEvents FinanSummDataView As DataGridView
    Friend WithEvents DownloadButton As Button

End Class
