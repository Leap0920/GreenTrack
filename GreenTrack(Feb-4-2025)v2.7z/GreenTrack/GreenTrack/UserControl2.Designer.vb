﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl2
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        Label3 = New Label()
        PlantName = New TextBox()
        Label1 = New Label()
        Label4 = New Label()
        Amount = New TextBox()
        Quantity = New TextBox()
        ProcessPaymentButton = New Button()
        PrintReceiptButton = New Button()
        Label5 = New Label()
        TextBox1 = New TextBox()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(498, 30)
        Label2.Name = "Label2"
        Label2.Size = New Size(284, 40)
        Label2.TabIndex = 3
        Label2.Text = "SALES PROCESSING"
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Top
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(381, 90)
        Label3.Name = "Label3"
        Label3.Size = New Size(70, 30)
        Label3.TabIndex = 13
        Label3.Text = "Plant:"
        ' 
        ' PlantName
        ' 
        PlantName.Anchor = AnchorStyles.Top
        PlantName.Font = New Font("Segoe UI", 15.75F)
        PlantName.Location = New Point(381, 123)
        PlantName.Multiline = True
        PlantName.Name = "PlantName"
        PlantName.Size = New Size(253, 41)
        PlantName.TabIndex = 12
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(660, 90)
        Label1.Name = "Label1"
        Label1.Size = New Size(105, 30)
        Label1.TabIndex = 11
        Label1.Text = "Quantity:"
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Top
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(795, 90)
        Label4.Name = "Label4"
        Label4.Size = New Size(100, 30)
        Label4.TabIndex = 14
        Label4.Text = "Amount:"
        ' 
        ' Amount
        ' 
        Amount.Anchor = AnchorStyles.Top
        Amount.Font = New Font("Segoe UI", 15.75F)
        Amount.Location = New Point(795, 123)
        Amount.Multiline = True
        Amount.Name = "Amount"
        Amount.Size = New Size(105, 41)
        Amount.TabIndex = 15
        Amount.TextAlign = HorizontalAlignment.Center
        ' 
        ' Quantity
        ' 
        Quantity.Anchor = AnchorStyles.Top
        Quantity.Font = New Font("Segoe UI", 15.75F)
        Quantity.Location = New Point(660, 123)
        Quantity.Multiline = True
        Quantity.Name = "Quantity"
        Quantity.Size = New Size(105, 41)
        Quantity.TabIndex = 10
        Quantity.TextAlign = HorizontalAlignment.Center
        ' 
        ' ProcessPaymentButton
        ' 
        ProcessPaymentButton.Anchor = AnchorStyles.Top
        ProcessPaymentButton.Location = New Point(494, 602)
        ProcessPaymentButton.Name = "ProcessPaymentButton"
        ProcessPaymentButton.Size = New Size(106, 35)
        ProcessPaymentButton.TabIndex = 16
        ProcessPaymentButton.Text = "Process Payment"
        ProcessPaymentButton.UseVisualStyleBackColor = True
        ' 
        ' PrintReceiptButton
        ' 
        PrintReceiptButton.Anchor = AnchorStyles.Top
        PrintReceiptButton.Location = New Point(681, 602)
        PrintReceiptButton.Name = "PrintReceiptButton"
        PrintReceiptButton.Size = New Size(106, 35)
        PrintReceiptButton.TabIndex = 17
        PrintReceiptButton.Text = "Print Receipt"
        PrintReceiptButton.UseVisualStyleBackColor = True
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.Top
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(381, 190)
        Label5.Name = "Label5"
        Label5.Size = New Size(163, 30)
        Label5.TabIndex = 18
        Label5.Text = "Receipt Details:"
        ' 
        ' TextBox1
        ' 
        TextBox1.Anchor = AnchorStyles.Top
        TextBox1.Font = New Font("Segoe UI", 15.75F)
        TextBox1.Location = New Point(381, 223)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(519, 373)
        TextBox1.TabIndex = 19
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' UserControl2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        Controls.Add(TextBox1)
        Controls.Add(Label5)
        Controls.Add(PrintReceiptButton)
        Controls.Add(ProcessPaymentButton)
        Controls.Add(Amount)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(PlantName)
        Controls.Add(Label1)
        Controls.Add(Quantity)
        Controls.Add(Label2)
        Name = "UserControl2"
        Size = New Size(1280, 720)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PlantName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Amount As TextBox
    Friend WithEvents Quantity As TextBox
    Friend WithEvents ProcessPaymentButton As Button
    Friend WithEvents PrintReceiptButton As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox1 As TextBox

End Class
