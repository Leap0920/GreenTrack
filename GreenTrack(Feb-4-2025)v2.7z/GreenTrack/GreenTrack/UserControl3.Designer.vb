﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl3
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label2 = New Label()
        SearchCustomer = New TextBox()
        CustomerDataView = New DataGridView()
        SearchButton = New Button()
        CType(CustomerDataView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Top
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(448, 23)
        Label2.Name = "Label2"
        Label2.Size = New Size(385, 40)
        Label2.TabIndex = 4
        Label2.Text = "CUSTOMER INFORMATION"
        ' 
        ' SearchCustomer
        ' 
        SearchCustomer.Anchor = AnchorStyles.Top
        SearchCustomer.Font = New Font("Segoe UI", 15.75F)
        SearchCustomer.Location = New Point(795, 103)
        SearchCustomer.Multiline = True
        SearchCustomer.Name = "SearchCustomer"
        SearchCustomer.Size = New Size(201, 41)
        SearchCustomer.TabIndex = 9
        SearchCustomer.TextAlign = HorizontalAlignment.Center
        ' 
        ' CustomerDataView
        ' 
        CustomerDataView.Anchor = AnchorStyles.Top
        CustomerDataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        CustomerDataView.Location = New Point(181, 160)
        CustomerDataView.Name = "CustomerDataView"
        CustomerDataView.Size = New Size(918, 458)
        CustomerDataView.TabIndex = 15
        ' 
        ' SearchButton
        ' 
        SearchButton.Anchor = AnchorStyles.Top
        SearchButton.Location = New Point(1002, 103)
        SearchButton.Name = "SearchButton"
        SearchButton.Size = New Size(97, 41)
        SearchButton.TabIndex = 16
        SearchButton.Text = "Search"
        SearchButton.UseVisualStyleBackColor = True
        ' 
        ' UserControl3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        Controls.Add(SearchButton)
        Controls.Add(CustomerDataView)
        Controls.Add(SearchCustomer)
        Controls.Add(Label2)
        Name = "UserControl3"
        Size = New Size(1280, 720)
        CType(CustomerDataView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents SearchCustomer As TextBox
    Friend WithEvents CustomerDataView As DataGridView
    Friend WithEvents SearchButton As Button

End Class
